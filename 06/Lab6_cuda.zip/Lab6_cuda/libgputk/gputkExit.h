
#ifndef __GPUTK_EXIT_H__
#define __GPUTK_EXIT_H__

void gpuTK_atExit(void);

#endif /* __GPUTK_EXIT_H__ */
